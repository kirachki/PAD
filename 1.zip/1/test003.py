from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
 
#Chromeブラウザを表示(環境変数のPATHにドライバーのパスを追加済とする)
driver = webdriver.Chrome()
 
#ページを表示
driver.get("https://www.yahoo.co.jp")
 
#新規タブを作成して、そのタブをアクティブにする。
driver.switch_to.new_window('tab')
 
#新規ウィンドウを作成して、そのウィンドウをアクティブにする。
driver.switch_to.new_window('window')