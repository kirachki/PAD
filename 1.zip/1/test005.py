

from selenium import webdriver
from selenium.webdriver.firefox.service import Service as FirefoxService
from tkinter import messagebox
import time
import selenium
# import selenium.webdriver # これも読込が必要

# WebDriverを起動
driver = webdriver.Firefox()

# 最初のウィンドウを開く
# driver.get('https://www.example.com')
driver.get('https://www.amazon.co.jp')

# 現在のウィンドウハンドルを取得
original_window = driver.current_window_handle

# 新しいウィンドウを開く（例：リンクをクリックして）
driver.execute_script("window.open('https://www.yahoo.co.jp');")
time.sleep(2)

# 新しいウィンドウハンドルを取得
new_window = driver.window_handles[1]
print(driver.title)
print(driver.page_source)


# ウィンドウを切り替える
driver.switch_to.window(new_window)
time.sleep(2)
print(driver.title)
print(driver.page_source)
current_window_title = driver.title
# messagebox.showinfo("今のウィンドは？", f"ウィンドウタイトル: {current_window_title}")

# 新しいウィンドウで何か操作を行う

# ウィンドウを切り替えて元のウィンドウに戻る
driver.switch_to.window(original_window)
time.sleep(2)
current_window_title = driver.title
messagebox.showinfo("今のウィンドは？", f"ウィンドウタイトル: {current_window_title}")

driver.switch_to.window(new_window)
time.sleep(2)

By = selenium.webdriver.common.by.By
elem = browser.find_element(By.ID, "Today")
print("DEBUG:", "id=Todayの要素:\n", elem, "\n")
# 結果: <selenium.webdriver.remote.webelement.WebElement (session="2b5ab6d7-3b50-4f45-97a4-ce33917c5a65", element="399cdc72-646b-44a2-8ec8-6f734136b626")>
print("DEBUG:", "要素のtext:\n", elem.text, "\n")
# 結果: '本日の天気、運行情報\n2021年12月11日(土)\n今日明日の天気\n ... お知らせ\n新着があります'


# ドライバーを閉じる
driver.quit()