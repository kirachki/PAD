from selenium import webdriver
from selenium.webdriver.firefox.service import Service as FirefoxService
# from webdriver_manager.firefox import GeckoDriverManager

options = webdriver.FirefoxOptions()
options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")
driver = webdriver.Firefox(service=FirefoxService(GeckoDriverManager().install()), options=options)

# ウィンドウ一覧を取得
window_handles = driver.window_handles
print("========== window1 ========== ")
window1 = driver.switch_to.window(window_handles[0])
print(driver.title)
print(driver.page_source)

print("========== window2 ========== ")
window2 = driver.switch_to.window(window_handles[1])
print(driver.title)
print(driver.page_source)