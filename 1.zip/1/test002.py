# Seleniumの試用 (Firefoxをコードで操作試行) 結果:成功

# assume: 以下、導入が必要
# ・pip install selenium
# ・geckodriver.exeのダウンロード
#     https://github.com/mozilla/geckodriver/releases/tag/v0.30.0
#     からgeckodriver-v0.30.0-win64.zipをダウンロード、geckodriver.exeが同梱、当スクリプトファイルと同じ場所に配置

# ref: Selenium を Firefox で使用する方法:
# https://qiita.com/Nw3965/items/81c29ee4e6bbf94b6e98
#
# ref: Selenium 4で「DeprecationWarning」が出る場合の対策:
# https://self-development.info/selenium-4%E3%81%A7%E3%80%8Cdeprecationwarning%E3%80%8D%E3%81%8C%E5%87%BA%E3%82%8B%E5%A0%B4%E5%90%88%E3%81%AE%E5%AF%BE%E7%AD%96/
#
# ref: Firefoxウィンドウを非表示で操作
# https://stackovergo.com/ja/q/1285949/how-to-hide-firefox-window-selenium-webdriver

import selenium
import selenium.webdriver # これも読込が必要

# sec: main

def main(): # 実行切替用
    test__main1()
    test__main2()

# Webサイトを表示・HTML DOM要素を取得
def test__main1():
    # 結果: 取得成功
    
    print("\n" + "-" * 40)
    print("selenium version:", selenium.__version__, "\n") # '4.1.0'

    # sec: driver取得 "geckodriver.exe"(Firefoxドライバ)を指定

    path_driver = r"./geckodriver.exe" # 当スクリプトファイルと同じ場所に"geckodriver.exe"を配置

    service = selenium.webdriver.firefox.service.Service(executable_path=path_driver) # "geckodriver.exe"(Firefoxドライバ)がある場所を指定
    browser = selenium.webdriver.Firefox(service=service)

    # sec: Webサイトを表示

    browser.get("https://www.yahoo.co.jp/")
    # 結果: Firefox(既定プロファイル)のウィンドウが開いて、Webサイトが表示され、成功。

    By = selenium.webdriver.common.by.By
    elem = browser.find_element(By.ID, "Today")
    print("DEBUG:", "id=Todayの要素:\n", elem, "\n")
    # 結果: <selenium.webdriver.remote.webelement.WebElement (session="2b5ab6d7-3b50-4f45-97a4-ce33917c5a65", element="399cdc72-646b-44a2-8ec8-6f734136b626")>
    print("DEBUG:", "要素のtext:\n", elem.text, "\n")
    # 結果: '本日の天気、運行情報\n2021年12月11日(土)\n今日明日の天気\n ... お知らせ\n新着があります'
    
    input("待機中。ブラウザを閉じる(Enter): ")
    
    browser.close()

# Firefoxウィンドウを非表示で操作
def test__main2():
    # 結果: 非表示成功

    import os
    os.environ['MOZ_HEADLESS'] = '1' # Firefox56以降の新機能

    test__main1()
    

# sec: entry

if __name__ == "__main__": main()
