from selenium import webdriver
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from tkinter import messagebox
import time 
 
#Firefoxブラウザを表示(環境変数のPATHにドライバーのパスを追加済とする)
driver = webdriver.Firefox()
 
#ページを表示
driver.get("https://www.yahoo.co.jp")
 
#アクティブなブラウザのウィンドウハンドルを保持する
original_window = driver.current_window_handle
 
#新規ウィンドウを開く
# driver.execute_script("window.open()")
driver.execute_script("window.open('https://www.google.co.jp');")
time.sleep(2)

 
#最初のウィンドウを表示
driver.switch_to.window(driver.window_handles[1])
 
#他のウィンドウをアクティブにする
for window_handle in driver.window_handles:
    if window_handle != original_window:
        driver.switch_to.window(window_handle)
        break
 
messagebox.showinfo("ウィンドウ・タブの切り替え")
  
#最初に開いたウィンドウ・タブに切り替える
driver.switch_to.window(driver.window_handles[0])
current_window_title = driver.title
messagebox.showinfo("最初に開いたウィンドウ・タブに切り替え", f"ウィンドウタイトル: {current_window_title}")
#最後に開いたウィンドウ・タブに切り替える
driver.switch_to.window(driver.window_handles[len(driver.window_handles) - 1])
messagebox.showinfo("最後に開いたウィンドウ・タブに切り替え");